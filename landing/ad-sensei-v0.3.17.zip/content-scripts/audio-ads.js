var audioAds=(function(){"use strict";var st=Object.defineProperty;var ot=(p,r,l)=>r in p?st(p,r,{enumerable:!0,configurable:!0,writable:!0,value:l}):p[r]=l;var m=(p,r,l)=>ot(p,typeof r!="symbol"?r+"":r,l);var M,R,u,U,a;function p(t){return t}const r={masterEnabled:!0,adEngineEnabled:!0,sponsorEngineEnabled:!0,blockAllAds:!0,blockTrackers:!0,blockCookieNotices:!0,blockSocial:!1,blockPopups:!0,blockMalware:!0,allowlist:[],confidenceThreshold:.7,sponsorBlockEnabled:!0,sponsorBlockCategories:["sponsor","selfpromo","interaction"],showSkipToast:!0,aiEnhancements:!0,aggressivePruning:!1,resumePlayback:!0,defuseAntiAdblock:!0,blockUrlTracking:!1,ytHideShorts:!1,ytDismissStillWatching:!1,ytDisableEndCards:!1,muteAudioAds:!0,localOnlyMode:!1,debugLogging:!1,telemetryEnabled:!0,filterUpdatesEnabled:!0,llmProvider:"builtin",apiKeys:{},model:"",fallbackProvider:"builtin",openclawUrl:"http://127.0.0.1:18789/v1/chat/completions"},l="skipSensei.settings";function c(){let t=Promise.resolve();return e=>(t=t.then(e).catch(()=>{}),t)}async function F(){const t=await chrome.storage.local.get(l);return{...r,...t[l]??{}}}c(),c();function Y(t){chrome.storage.onChanged.addListener((e,n)=>{n==="local"&&e[l]&&t({...r,...e[l].newValue})})}c(),c(),c(),c(),c(),c(),c();const y="spotifyNoteDismissed",s="skip-sensei-spotify-notice",_=`${s}-style`,q=`
#${s} {
  position: fixed;
  top: 76px;
  right: 16px;
  z-index: 2147483000;
  width: 360px;
  max-width: calc(100vw - 32px);
  box-sizing: border-box;
  padding: 12px 34px 12px 14px;
  border-radius: 12px;
  background: #181818;
  border: 1px solid rgba(30, 215, 96, 0.5);
  box-shadow: 0 8px 28px rgba(0, 0, 0, 0.55);
  color: #fff;
  font: 400 13px/1.45 "CircularSp", "Circular", "Helvetica Neue", Arial, sans-serif;
  opacity: 0;
  transform: translateY(-6px);
  transition: opacity 0.25s, transform 0.25s;
}
#${s}.skip-sensei-visible { opacity: 1; transform: translateY(0); }
#${s} .ss-title {
  display: flex; align-items: center; gap: 8px; white-space: nowrap;
  font-weight: 700; font-size: 13.5px; margin-bottom: 4px;
}
#${s} .ss-title::before {
  content: ""; width: 7px; height: 7px; border-radius: 50%; flex: none;
  background: #1ed760; box-shadow: 0 0 8px #1ed760;
}
#${s} .ss-title b { color: #1ed760; font-weight: 700; }
#${s} .ss-brand { font-size: 10.5px; font-weight: 600; letter-spacing: 0.08em; color: #a7a7a7; align-self: center; }
#${s} p { margin: 0; color: #d6d6d6; }
#${s} .ss-actions { margin-top: 10px; display: flex; justify-content: space-between; align-items: center; }
#${s} .ss-ok {
  border: 0; border-radius: 999px; padding: 6px 14px; cursor: pointer;
  background: #1ed760; color: #000; font: 700 12.5px/1 inherit;
}
#${s} .ss-ok:hover { background: #3be477; }
#${s} .ss-x {
  position: absolute; top: 6px; right: 6px; width: 24px; height: 24px;
  border: 0; border-radius: 6px; background: transparent; color: #a7a7a7;
  font-size: 18px; line-height: 1; cursor: pointer;
}
#${s} .ss-x:hover { color: #fff; background: rgba(255,255,255,0.08); }
`;async function O(){if(document.getElementById(s))return;try{if((await chrome.storage.local.get(y))[y]===!0)return}catch{return}if(!document.getElementById(_)){const n=document.createElement("style");n.id=_,n.textContent=q,document.documentElement.appendChild(n)}const t=document.createElement("div");t.id=s,t.setAttribute("role","status"),t.innerHTML=`
    <button type="button" class="ss-x" aria-label="Dismiss">\xD7</button>
    <div class="ss-title"><span>Spotify ads are <b>muted</b>, not skipped</span></div>
    <p>Spotify's web player delivers ads in-stream with skip locked for free accounts \u2014 there's no ad request to block and nothing to skip to. Ad Sensei mutes this tab the moment an ad starts and unmutes when the music returns. You'll see ads go by; you won't hear them.</p>
    <div class="ss-actions"><span class="ss-brand">AD SENSEI</span><button type="button" class="ss-ok">Got it</button></div>
  `;const e=()=>{t.classList.remove("skip-sensei-visible"),setTimeout(()=>t.remove(),250),chrome.storage.local.set({[y]:!0}).catch(()=>{})};t.querySelector(".ss-x").addEventListener("click",e),t.querySelector(".ss-ok").addEventListener("click",e),(document.body??document.documentElement).appendChild(t),requestAnimationFrame(()=>t.classList.add("skip-sensei-visible"))}const G=new Set(["Advertisement","Anuncio","An\xFAncio","Publicit\xE9","Werbung","Pubblicit\xE0","Advertentie","Reklam","Reklama","\u0420\u0435\u043A\u043B\u0430\u043C\u0430","\u5E83\u544A","\uAD11\uACE0","\u5E7F\u544A","\u5EE3\u544A"].map(t=>t.toLowerCase())),W='[data-testid="now-playing-widget"]',V='[data-testid="context-item-info-title"]',z=1e3,B=18e4,H=1500;let v=null,b=!1,d=!1,k=0,C=!1,f=0,S=null,h=null;function K(t){const e=location.hostname,n=e.replace(/^www\./,"");return t.includes(e)||t.includes(n)}function j(t){return t.masterEnabled&&t.blockAllAds&&t.muteAudioAds&&!K(t.allowlist)}function w(t){return t?G.has(t.trim().toLowerCase()):!1}function X(){const t=document.querySelector(W);if(t){const e=t.querySelector(V);if(w(e==null?void 0:e.textContent))return!0;const n=t.getAttribute("aria-label");if(n){if(w(n))return!0;const i=n.slice(n.indexOf(":")+1),[o]=i.split(/\s+by\s+/i);if(w(o))return!0}}return document.title.split(/\s+[•\-–|]\s+/).some(w)}function P(t){try{return chrome.runtime.sendMessage(t).catch(()=>null)}catch{return N(),Promise.resolve(null)}}async function g(t){if(t===d)return;const e=await P({type:"skipSensei:muteTab",muted:t});if(t){if(e!==!0)return;d=!0,k=Date.now(),document.documentElement.setAttribute("data-ad-sensei-muted","1")}else{const n=((Date.now()-k)/1e3).toFixed(1);d=!1,document.documentElement.removeAttribute("data-ad-sensei-muted"),P({type:"skipSensei:event",kind:"audio_ad_muted",fields:{seconds:n}})}}function I(){if(!b)return;const t=X(),e=Date.now();if(!t){C=!1,d&&(f===0&&(f=e),e-f>=H&&(f=0,g(!1)));return}if(f=0,!C){if(d&&e-k>B){C=!0,g(!1);return}d||g(!0)}}function J(){b||(b=!0,O(),S=setInterval(I,z),h=new MutationObserver(()=>I()),h.observe(document.body,{subtree:!0,childList:!0,characterData:!0,attributeFilter:["aria-label"]}),I())}function N(){b&&(b=!1,S&&clearInterval(S),S=null,h==null||h.disconnect(),h=null,f=0,d&&g(!1))}function D(){v&&(j(v)?J():N())}window.addEventListener("pagehide",()=>{d&&g(!1)}),F().then(t=>{v=t,D()}),Y(t=>{v=t,D()});const Q={matches:["*://open.spotify.com/*"],runAt:"document_idle",main(){}};function x(t,...e){}const Z={debug:(...t)=>x(console.debug,...t),log:(...t)=>x(console.log,...t),warn:(...t)=>x(console.warn,...t),error:(...t)=>x(console.error,...t)},A=(R=(M=globalThis.browser)==null?void 0:M.runtime)!=null&&R.id?globalThis.browser:globalThis.chrome;var $=(u=class extends Event{constructor(e,n){super(u.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=n}},m(u,"EVENT_NAME",L("wxt:locationchange")),u);function L(t){var e;return`${(e=A==null?void 0:A.runtime)==null?void 0:e.id}:audio-ads:${t}`}const tt=typeof((U=globalThis.navigation)==null?void 0:U.addEventListener)=="function";function et(t){let e,n=!1;return{run(){n||(n=!0,e=new URL(location.href),tt?globalThis.navigation.addEventListener("navigate",i=>{const o=new URL(i.destination.url);o.href!==e.href&&(window.dispatchEvent(new $(o,e)),e=o)},{signal:t.signal}):t.setInterval(()=>{const i=new URL(location.href);i.href!==e.href&&(window.dispatchEvent(new $(i,e)),e=i)},1e3))}}}var nt=(a=class{constructor(e,n){m(this,"id");m(this,"abortController");m(this,"locationWatcher",et(this));this.contentScriptName=e,this.options=n,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){var e;return((e=A.runtime)==null?void 0:e.id)==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,n){const i=setInterval(()=>{this.isValid&&e()},n);return this.onInvalidated(()=>clearInterval(i)),i}setTimeout(e,n){const i=setTimeout(()=>{this.isValid&&e()},n);return this.onInvalidated(()=>clearTimeout(i)),i}requestAnimationFrame(e){const n=requestAnimationFrame((...i)=>{this.isValid&&e(...i)});return this.onInvalidated(()=>cancelAnimationFrame(n)),n}requestIdleCallback(e,n){const i=requestIdleCallback((...o)=>{this.signal.aborted||e(...o)},n);return this.onInvalidated(()=>cancelIdleCallback(i)),i}addEventListener(e,n,i,o){var E;n==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(E=e.addEventListener)==null||E.call(e,n.startsWith("wxt:")?L(n):n,i,{...o,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),Z.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){var e;document.dispatchEvent(new CustomEvent(a.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),(e=this.options)!=null&&e.noScriptStartedPostMessage||window.postMessage({type:a.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},"*")}verifyScriptStartedEvent(e){var o,E;const n=((o=e.detail)==null?void 0:o.contentScriptName)===this.contentScriptName,i=((E=e.detail)==null?void 0:E.messageId)===this.id;return n&&!i}listenForNewerScripts(){const e=n=>{!(n instanceof CustomEvent)||!this.verifyScriptStartedEvent(n)||this.notifyInvalidated()};document.addEventListener(a.SCRIPT_STARTED_MESSAGE_TYPE,e),this.onInvalidated(()=>document.removeEventListener(a.SCRIPT_STARTED_MESSAGE_TYPE,e))}},m(a,"SCRIPT_STARTED_MESSAGE_TYPE",L("wxt:content-script-started")),a);function at(){}function T(t,...e){}const it={debug:(...t)=>T(console.debug,...t),log:(...t)=>T(console.log,...t),warn:(...t)=>T(console.warn,...t),error:(...t)=>T(console.error,...t)};return(async()=>{try{const{main:t,...e}=Q;return await t(new nt("audio-ads",e))}catch(t){throw it.error('The content script "audio-ads" crashed on startup!',t),t}})()})();

audioAds;