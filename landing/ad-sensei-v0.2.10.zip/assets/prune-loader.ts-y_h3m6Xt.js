(function(){window.addEventListener("message",n=>{if(n.source!==window)return;const e=n.data;if((e==null?void 0:e.source)!=="skip-sensei"||(e==null?void 0:e.type)!=="ads-pruned")return;const s=typeof e.count=="number"&&e.count>0?e.count:1;try{chrome.runtime.sendMessage({type:"skipSensei:adSkipped",method:"pruned",count:s}).catch(()=>{})}catch{}});
})()
