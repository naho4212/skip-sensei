import './assets/service-worker.ts-BYUIBLsw.js';
