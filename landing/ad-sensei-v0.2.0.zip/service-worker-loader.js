import './assets/service-worker.ts-DR7cworF.js';
