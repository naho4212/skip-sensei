(function(){let t=0;window.addEventListener("message",s=>{if(s.source!==window)return;const e=s.data;if((e==null?void 0:e.source)!=="skip-sensei"||(e==null?void 0:e.type)!=="ads-pruned")return;const n=Date.now();if(!(n-t<1e4)){t=n;try{chrome.runtime.sendMessage({type:"skipSensei:adSkipped",method:"pruned"}).catch(()=>{})}catch{}}});
})()
