import './assets/service-worker.ts-5G3nowCo.js';
