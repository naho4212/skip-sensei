import './assets/service-worker.ts-BFNCL5J2.js';
